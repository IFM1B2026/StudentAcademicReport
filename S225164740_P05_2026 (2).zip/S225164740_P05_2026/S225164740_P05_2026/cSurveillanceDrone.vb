﻿Public Class cSurveillanceDrone

    Inherits Drone

    Private _radarRange As Double
    Private _alertSensitivity As Double
    Private _armorRating As Double

    Public Sub New(serialCode As String, batteryLevel As Double,
                   radarRange As Double, alertSensitivity As Double, armorRating As Double)
        MyBase.New(serialCode, batteryLevel)
        _radarRange = radarRange
        _alertSensitivity = alertSensitivity
        _armorRating = armorRating
    End Sub

    Public Function Scan() As Double
        Return _radarRange + _alertSensitivity + _armorRating
    End Function

    Public Overrides Function Defend() As Double
        Return _armorRating * _alertSensitivity
    End Function

    Public Overrides Function Display() As String
        Return "SURVEILLANCE DRONE " &
               "Radar Range: " & _radarRange & Environment.NewLine &
               "Battery Level: " & BatteryLevel & Environment.NewLine &
               "Serial Code: " & SerialCode & Environment.NewLine &
               "Alert Sensitivity: " & _alertSensitivity & Environment.NewLine &
               "Armor Rating: " & _armorRating & Environment.NewLine &
               "SCAN = " & Scan() & Environment.NewLine &
               "DEFEND = " & Defend()
    End Function
End Class
