﻿Public Class cSanitationDrone

    Inherits Drone

    Private _sprayPressure As Double
    Private _sensorPrecision As Double
    Private _ecoImpact As Double

    Public Sub New(serialCode As String, batteryLevel As Double,
                   sprayPressure As Double, sensorPrecision As Double, ecoImpact As Double)
        MyBase.New(serialCode, batteryLevel)
        _sprayPressure = sprayPressure
        _sensorPrecision = sensorPrecision
        _ecoImpact = ecoImpact
    End Sub

    Public Function Clean() As Double
        Return _sensorPrecision * _sprayPressure
    End Function

    Public Overrides Function Defend() As Double
        Return _ecoImpact * BatteryLevel
    End Function

    Public Overrides Function Display() As String
        Return "SANITATION DRONE " &
               "Spray Pressure: " & _sprayPressure & Environment.NewLine &
               "Battery Level: " & BatteryLevel & Environment.NewLine &
               "Serial Code: " & SerialCode & Environment.NewLine &
               "Sensor Precision: " & _sensorPrecision & Environment.NewLine &
               "Eco Impact: " & _ecoImpact & Environment.NewLine &
               "CLEAN = " & Clean() & Environment.NewLine &
               "DEFEND = " & Defend()
    End Function
End Class
