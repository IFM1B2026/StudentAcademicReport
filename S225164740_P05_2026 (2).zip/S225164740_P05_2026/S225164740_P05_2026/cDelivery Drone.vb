﻿Public Class cDeliveryDrone

    Inherits Drone

    Private _payloadCapacity As Double
    Private _flightSpeed As Double
    Private _navigationAccuracy As Double

    Public Sub New(serialCode As String, batteryLevel As Double,
                   payloadCapacity As Double, flightSpeed As Double, navigationAccuracy As Double)
        MyBase.New(serialCode, batteryLevel)
        _payloadCapacity = payloadCapacity
        _flightSpeed = flightSpeed
        _navigationAccuracy = navigationAccuracy
    End Sub

    Public Function Work() As Double
        Return _flightSpeed * _payloadCapacity
    End Function

    Public Overrides Function Defend() As Double
        Return _navigationAccuracy * BatteryLevel
    End Function

    Public Overrides Function Display() As String
        Return "DELIVERY DRONE " &
           "Payload Capacity: " & _payloadCapacity & Environment.NewLine &
           "Battery Level: " & BatteryLevel & Environment.NewLine &
           "Serial Code: " & SerialCode & Environment.NewLine &
           "Flight Speed: " & _flightSpeed & Environment.NewLine &
           "Navigation Accuracy: " & _navigationAccuracy & Environment.NewLine &
           "WORK = " & Work() & Environment.NewLine &
           "DEFEND = " & Defend()
    End Function
End Class
