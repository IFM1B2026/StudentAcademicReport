﻿Public MustInherit Class Drone
    Private ReadOnly _serialCode As String 'SerialCode cannot be changed once assigned
    Protected _batteryLevel As Double

    Public Sub New(serialCode As String, batteryLevel As Double)
        _serialCode = serialCode
        _batteryLevel = batteryLevel
    End Sub

    'Public properties to access them
    Public ReadOnly Property SerialCode As String
        Get
            Return _serialCode
        End Get
    End Property

    Public Property BatteryLevel As Double
        Get
            Return _batteryLevel
        End Get
        Set(value As Double)
            _batteryLevel = value
        End Set
    End Property

    ' Polymorphic methods
    Public MustOverride Function Defend() As Double
    Public MustOverride Function Display() As String
End Class
