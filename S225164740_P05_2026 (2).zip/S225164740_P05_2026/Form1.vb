﻿Public Class frmTestingALLTheAperationalAbilitiesOfTheirSpecializedEcoDronesAcrossModernSmartCities

    'variable decleration
    Private _SanDrone() As cSanitationDrone
    Private _delDrone() As cDeliveryDrone
    Private _survDrone() As cSurveillanceDrone
    Private nDelivery, nSanitation, nSurveillance As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Set multiline textbox to true, and vertical scrollbars
        txtDisplay.Multiline = True
        txtDisplay.ScrollBars = ScrollBars.Vertical
    End Sub

    Private Sub RedimArray()

        'Redim array
        ReDim _delDrone(nDelivery)
        ReDim _SanDrone(nSanitation)
        ReDim _survDrone(nSurveillance)
    End Sub

    Private Sub btnSet_Click(sender As Object, e As EventArgs) Handles btnSet.Click

        'This button allow the user to specify any number of delivery drone, sanitation drone, and surveillance drone.
        nDelivery = CInt(InputBox("Enter number of delivery drone"))
        nSanitation = CInt(InputBox("Enter number of sanitation drone"))
        nSurveillance = CInt(InputBox("Enter number od surveillance drone"))

        RedimArray()
    End Sub

    Private Sub btnInput_Click(sender As Object, e As EventArgs) Handles btnInput.Click

        'Input Delivery Drones
        For i As Integer = 1 To nDelivery
            Dim serial As String = InputBox("Enter serial code for Delivery Drone ")
            Dim battery As Double = CDbl(InputBox("Enter battery level for Delivery Drone"))
            Dim payload As Double = CDbl(InputBox("Enter payload capacity"))
            Dim speed As Double = CDbl(InputBox("Enter flight speed"))
            Dim navAcc As Double = CDbl(InputBox("Enter navigation accuracy"))

            _delDrone(i) = New cDeliveryDrone(serial, battery, payload, speed, navAcc)
        Next

        'Input Sanitation Drones
        For j As Integer = 1 To nSanitation
            Dim serial As String = InputBox("Enter serial code for Sanitation Drone ")
            Dim battery As Double = CDbl(InputBox("Enter battery level for Sanitation Drone"))
            Dim spray As Double = CDbl(InputBox("Enter spray pressure"))
            Dim sensor As Double = CDbl(InputBox("Enter sensor precision"))
            Dim eco As Double = CDbl(InputBox("Enter eco impact"))

            _SanDrone(j) = New cSanitationDrone(serial, battery, spray, sensor, eco)
        Next

        'Input Surveillance Drones
        For k As Integer = 1 To nSurveillance
            Dim serial As String = InputBox("Enter serial code for Surveillance Drone ")
            Dim battery As Double = CDbl(InputBox("Enter battery level for Surveillance"))
            Dim radar As Double = CDbl(InputBox("Enter radar range"))
            Dim alert As Double = CDbl(InputBox("Enter alert sensitivity"))
            Dim armor As Double = CDbl(InputBox("Enter armor rating"))

            _survDrone(k) = New cSurveillanceDrone(serial, battery, radar, alert, armor)
        Next
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'This button calls the functions, where calculations were done.

        'DeliveryDrone calculations
        For i As Integer = 1 To nDelivery
            Dim workCalc As Double = _delDrone(i).Work()
            Dim defendCalc As Double = _delDrone(i).Defend()
        Next

        'SanitationDrone calculations
        For j As Integer = 1 To nSanitation
            Dim cleanCalc As Double = _SanDrone(j).Clean()
            Dim defendCalc As Double = _SanDrone(j).Defend()
        Next

        'SurveillanceDrone calculations
        For k As Integer = 1 To nSurveillance
            Dim scanCalc As Double = _survDrone(k).Scan()
            Dim defendCalc As Double = _survDrone(k).Defend()
        Next
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click

        'call Display functions to display the information of each Drone in a multi-line textbox.
        txtDisplay.Text = ""

        For i As Integer = 1 To nDelivery
            txtDisplay.Text &= _delDrone(i).Display() & Environment.NewLine & Environment.NewLine
        Next

        For j As Integer = 1 To nSanitation
            txtDisplay.Text &= _SanDrone(j).Display() & Environment.NewLine & Environment.NewLine
        Next

        For k As Integer = 1 To nSurveillance
            txtDisplay.Text &= _survDrone(k).Display() & Environment.NewLine & Environment.NewLine
        Next
    End Sub
End Class
